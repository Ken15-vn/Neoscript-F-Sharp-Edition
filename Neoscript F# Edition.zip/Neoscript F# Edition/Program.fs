﻿// For more information see https://aka.ms/fsharp-console-apps
open System
open System.Collections.Generic
open System.IO
open System.Threading

// Quản lý biến bằng Dictionary (Hệ .NET)
let vars = Dictionary<string, string>()

let runInterpreter () =
    let fileName = "ide.ns"
    if File.Exists(fileName) then
        let lines = File.ReadAllLines(fileName)
        for rawLine in lines do
            let line = rawLine.Trim()
            // Bỏ qua dòng trống hoặc ghi chú
            if not (String.IsNullOrWhiteSpace(line) || line.StartsWith("note")) then
                // Tách lệnh và tham số
                let parts = line.Split([| ' ' |], 2, StringSplitOptions.RemoveEmptyEntries)
                let cmd = parts.[0].ToLower()
                let arg = if parts.Length > 1 then parts.[1] else ""

                match cmd with
                | "write" -> 
                    let content = arg.Trim('"')
                    if vars.ContainsKey(content) then printfn "%s" vars.[content]
                    else printfn "%s" content

                | "set" ->
                    let s = arg.Split([| ' ' |], 2)
                    if s.Length = 2 then vars.[s.[0]] <- s.[1].Trim('"')

                | "color" ->
                    match arg.Trim('"') with
                    | "cyan" -> Console.ForegroundColor <- ConsoleColor.Cyan
                    | "green" -> Console.ForegroundColor <- ConsoleColor.Green
                    | "red" -> Console.ForegroundColor <- ConsoleColor.Red
                    | _ -> Console.ResetColor()

                | "wait" -> 
                    let success, time = Double.TryParse(arg)
                    if success then Thread.Sleep(int(time * 1000.0))

                | "clear" -> Console.Clear()
                | _ -> ()
    else
        printfn "Error: %s not found!" fileName

// Điểm khởi đầu của chương trình
runInterpreter()