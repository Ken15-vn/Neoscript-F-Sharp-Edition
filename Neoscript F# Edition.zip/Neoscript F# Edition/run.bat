@echo off
title NeoScript F# Edition Launcher
cls
"Neoscript F# Edition.exe"
pause