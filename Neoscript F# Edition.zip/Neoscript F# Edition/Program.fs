﻿// For more information see https://aka.ms/fsharp-console-apps
open System
open System.Collections.Generic
open System.IO
open System.Threading

// Dictionary lưu trữ biến (Key là tên biến, Value là giá trị)
let vars = Dictionary<string, string>()

let runInterpreter () =
    let fileName = "ide.ns"
    if File.Exists(fileName) then
        let lines = File.ReadAllLines(fileName)
        for rawLine in lines do
            let line = rawLine.Trim()
            if not (String.IsNullOrWhiteSpace(line) || line.StartsWith("note")) then
                let parts = line.Split([| ' ' |], 2, StringSplitOptions.RemoveEmptyEntries)
                let cmd = parts.[0].ToLower()
                let arg = if parts.Length > 1 then parts.[1] else ""

                match cmd with
                | "write" -> 
                    let content = arg.Trim('"')
                    if vars.ContainsKey(content) then printfn "%s" vars.[content]
                    else printfn "%s" content

                | "set" ->
                    let s = arg.Split([| ' ' |], 2)
                    if s.Length = 2 then vars.[s.[0]] <- s.[1].Trim('"')

                | "input" ->
                    printf "Input numeric value for %s: " arg
                    let inputVal = Console.ReadLine()
                    vars.[arg] <- inputVal

                | "input_str" ->
                    printf "Input text for %s: " arg
                    let inputVal = Console.ReadLine()
                    vars.[arg] <- inputVal

                | "add" ->
                    let s = arg.Split([| ' ' |], 2)
                    if s.Length = 2 && vars.ContainsKey(s.[0]) then
                        let current = float vars.[s.[0]]
                        let toAdd = if vars.ContainsKey(s.[1]) then float vars.[s.[1]] else float s.[1]
                        vars.[s.[0]] <- string (current + toAdd)

                | "sub" ->
                    let s = arg.Split([| ' ' |], 2)
                    if s.Length = 2 && vars.ContainsKey(s.[0]) then
                        let current = float vars.[s.[0]]
                        let toSub = if vars.ContainsKey(s.[1]) then float vars.[s.[1]] else float s.[1]
                        vars.[s.[0]] <- string (current - toSub)

                | "color" ->
                    match arg.Trim('"') with
                    | "cyan" -> Console.ForegroundColor <- ConsoleColor.Cyan
                    | "green" -> Console.ForegroundColor <- ConsoleColor.Green
                    | "red" -> Console.ForegroundColor <- ConsoleColor.Red
                    | _ -> Console.ResetColor()

                | "wait" -> 
                    let success, time = Double.TryParse(arg)
                    if success then Thread.Sleep(int(time * 1000.0))

                | "clear" -> Console.Clear()
                | _ -> ()
    else
        printfn "Error: %s not found!" fileName

runInterpreter()